import React, { useState, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import OTPVerification from './components/OTPVerification';
import PasswordReset from './components/PasswordReset';
import AdminPanel from './components/AdminPanel';
import authService from './services/authService';
import roleService from './services/roleService';
import { RoleEnum, UserInfo } from './types/roles';

type AuthStep = 'login' | 'otp' | 'password-reset' | 'admin';

function App() {
  const [currentStep, setCurrentStep] = useState<AuthStep>('login');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userPhone, setUserPhone] = useState('');
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);

  // Check if user is already authenticated
  useEffect(() => {
    const { authToken, userId } = authService.getAuthData();
    if (authToken && userId) {
      setUserInfo({ authToken, userId });
      setCurrentStep('admin');
      
      // Fetch user role
      roleService.getUserRole(userId, authToken).then(role => {
        setUserInfo(prev => prev ? { ...prev, role } : null);
      });
    }
  }, []);

  const fetchUserRole = async (userId: number, authToken: string) => {
    try {
      const role = await roleService.getUserRole(userId, authToken);
      setUserInfo(prev => prev ? { ...prev, role } : null);
    } catch (error) {
      console.error('Error fetching user role:', error);
      // Default to customer role if fetch fails
      setUserInfo(prev => prev ? { ...prev, role: RoleEnum.CUSTOMER } : null);
    }
  };

  const handleLogin = async (phone: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await authService.login(phone, password);
      authService.saveAuthData(response.data.authToken, response.data.userId);
      const newUserInfo = {
        authToken: response.data.authToken,
        userId: response.data.userId,
      };
      setUserInfo(newUserInfo);
      await fetchUserRole(response.data.userId, response.data.authToken);
      setCurrentStep('admin');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (phone: string) => {
    setLoading(true);
    setError(null);
    
    try {
      await authService.generateOTP(phone);
      setUserPhone(phone);
      setCurrentStep('otp');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (otpCode: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await authService.loginWithOTP(userPhone, otpCode);
      authService.saveAuthData(response.data.authToken, response.data.userId);
      const newUserInfo = {
        authToken: response.data.authToken,
        userId: response.data.userId,
      };
      setUserInfo(newUserInfo);
      await fetchUserRole(response.data.userId, response.data.authToken);
      setCurrentStep('password-reset');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'OTP verification failed');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    try {
      await authService.generateOTP(userPhone);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resend OTP');
    }
  };

  const handleResetPassword = async (newPassword: string) => {
    if (!userInfo) return;
    
    setLoading(true);
    setError(null);
    
    try {
      await authService.updatePassword(userInfo.userId, newPassword, userInfo.authToken);
      setCurrentStep('admin');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update password');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    authService.clearAuthData();
    setUserInfo(null);
    setCurrentStep('login');
    setError(null);
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'login':
        return (
          <LoginForm
            onLogin={handleLogin}
            onForgotPassword={handleForgotPassword}
            loading={loading}
            error={error}
          />
        );
      case 'otp':
        return (
          <OTPVerification
            phone={userPhone}
            onVerifyOTP={handleVerifyOTP}
            onResendOTP={handleResendOTP}
            loading={loading}
            error={error}
          />
        );
      case 'password-reset':
        return (
          <PasswordReset
            onResetPassword={handleResetPassword}
            loading={loading}
            error={error}
          />
        );
      case 'admin':
        return (
          <AdminPanel
            onLogout={handleLogout}
            userInfo={{ 
              userId: userInfo!.userId, 
              role: userInfo!.role || RoleEnum.CUSTOMER,
              authToken: userInfo!.authToken
            }}
          />
        );
      default:
        return null;
    }
  };

  if (currentStep === 'admin') {
    return renderCurrentStep();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {renderCurrentStep()}
      </div>
    </div>
  );
}

export default App;